function exportFunction(name) {
 
   if (!window.Blob) {
      alert('Your browser does not support this action.');
      return;
   }

   var html, link, blob, url, css;
   
   // EU A4 use: size: 841.95pt 595.35pt;
   // US Letter use: size:11.0in 8.5in;
   
   css = (
     '<style>' +
     '@page WordSection1{size: 841.95pt 595.35pt;mso-page-orientation: landscape;}' +
     'div.WordSection1 {page: WordSection1;}' +
     'table{border-collapse:collapse;}'+
	 'td{border:1px #E9E9E9 solid;padding:2px;}'+
	 'th{background-color: #ABFF8F;padding:2px;}'+
	 'BODY {background-color: #ffffff;font-family: Arial, Helvetica, Tahoma;font-size: 9pt;}'+
     '</style>'
   );
   
   html = window.docx.innerHTML;
   blob = new Blob(['\ufeff', css + html], {
     type: 'application/msword'
   });
   url = URL.createObjectURL(blob);
   link = document.createElement('A');
   link.href = url;
   // Set default file name. 
   // Word will append file extension - do not add an extension here.
   link.download = name;   
   document.body.appendChild(link);
   if (navigator.msSaveOrOpenBlob ) navigator.msSaveOrOpenBlob( blob, name + '.doc'); // IE10-11
   		else link.click();  // other browsers
   document.body.removeChild(link);
 }